# Python_CDS_Assignment2

## using Python, Jupyter Notebook, Pandas, Numpy

<p align="justify"> Hi this is code for the assignment 1 from Citizen Data Scientist Program Batch 3

### Some Important notes:

- Please know that I use python venv while doing this. There might be differences with your installed library. Although this project is straighforward, it should not cause much issue.
- All you need for the dependencies library is in the requirements.txt

### How to install:

```
$ pip install -r requirements.txt
```

### How to use:

PLEASE NOTE: it needs 1 command after the filename!

```
Run it in jupyter notebook
```

### More references:

https://pandas.pydata.org/docs/index.html
https://docs.python.org/3/library/math.html
https://matplotlib.org/cheatsheets/
https://matplotlib.org/3.6.0/index.html
https://numpy.org/doc/1.23/
